STAND_LS_NCDA.m 
performs the Non-Contiguous Drought Analysis (NCDA) proposed by Corzo et al. (2011 HESS), on a monthly basis. Furthermore, it computes drought characteristics (i.e., Duration, Severity and Intensity=D/S) from one arrangement (rows x cols x time) containing drought indicator values. 

STAND_LS_NCDA_application.m 
Illustrates, step by step, the use of STAND_LS_NCDA.m by using the Standardized Precipitation Evaporation Index (SPEI) as drought indicator (Vicente-Serrano et al. 2010 JC), but it is possible to use another.

References
Corzo, G. A., Van Huijgevoort, M. H. J., Vo�, F., & Van Lanen, H. A. J. (2011). On the spatio-temporal analysis of hydrological droughts from global hydrological models. Hydrology and Earth System Sciences, 15(9), 2963�2978. http://doi.org/10.5194/hess-15-2963-2011 

Vicente-Serrano, S. M., Begueria, S., & Lopez-Moreno, J. I. (2010). A multiscalar drought index sensitive to global warming: The standardized precipitation evapotranspiration index. Journal of Climate, 23(7), 1696�1718. http://doi.org/10.1175/2009JCLI2909.1 

by Vitali Diaz
vitalidime@gmail.com
IHE Delft

have a look at https://github.com/hydroinfo4x!